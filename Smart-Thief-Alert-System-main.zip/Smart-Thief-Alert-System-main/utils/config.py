# Configuration settings for the project
MONGODB_URI = 'mongodb://localhost:27017/'
DATABASE_NAME = 'SmartThiefAlertSystem'
EMAIL_ADDRESS = 'mathanraj.mp2003@gmail.com'
EMAIL_PASSWORD = 'Mathan.45@'
IMAGE_PATH = 'C:/Users/matha/OneDrive/Desktop/Smart Thief Alert System/images/pic1.jpg'
